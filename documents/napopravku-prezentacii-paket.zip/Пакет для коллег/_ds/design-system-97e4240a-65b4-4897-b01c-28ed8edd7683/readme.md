# НаПоправку — Design System

Source: a Figma file titled "style slide Cloade.fig" (mounted read-only; no public share link was provided) containing a brand style-guide page (`/norm` — color, type, logo, icon, grid, 3D illustrations) and a sales pitch-deck page (`/slide` — 21 slide frames) plus a chart-components page (`/charts`). Fonts `Montserrat-Regular/Medium/Bold.otf` were supplied as uploads.

**НаПоправку** ("Get well soon" / "Na Popravku") is a Russian booking service connecting patients with medical clinics ("сервис записи в медицинские центры России"). This design system captures its B2B pitch-deck brand — the material used to sell clinics on joining the platform ("Для клиник" — "For clinics"), not the consumer product UI (no app/site screens were present in the source file).

## Sources
- Figma file: "style slide Cloade.fig" (mounted VFS; pages `/norm`, `/slide`, `/charts`)
- Uploaded fonts: `uploads/Montserrat-{Regular,Medium,Bold}.otf`

## Index
- `styles.css` — root stylesheet, imports everything below
- `tokens/` — colors, typography, spacing, fonts (`fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `fig/fig-tokens.css` generated from Figma Variables)
- `assets/icons/` — 17-glyph icon set (`Icon.jsx`, icon-data.js)
- `assets/illustrations/` — full-color 3D illustration renders (photography-style clinic/telemed imagery)
- `assets/fonts/` — Montserrat OTF files
- `components/brand/` — Logo (9 variants), and decorative swatch/shape components extracted from the color page
- `components/core/` — IconTile, Badge, InfoCard, StatBar, ListItemCheck (intentional additions — see below)
- `guidelines/` — foundation specimen cards (colors, type, spacing, radii, shadows, illustrations)
- `templates/pitch-deck/` — a 5-slide deck template (title, checklist, chart, image, calendar/table layouts) in this brand
- `thumbnail.html` — homepage tile

## Components
- **Logo** (`components/brand`) — the only true component *set* in the source: 9 variants (`prop`: icon | logo × `prop2`: main | white | main-white | dark | white-stroke).
- **Background, CardStyle, MainForm, Rectangle240654316, Component5** (`components/brand`) — standalone rounded-rectangle/shape symbols used as swatches on the color page; kept as-is from the source.
- **Icon** (`assets/icons`) — wraps the 17-glyph icon set (`ArrowCircleUpRight, BankNote01, BarChart12, Briefcase01, ChecEmoji, CheckCircle, CoinsHand, FaceSmile, Mail01, MarkerPin01, MessageCheckSquare, MessageDotsCircle, OutlinedLipsCircle24, OutlinedMat24, OutlinedTest24, PhoneCall01, User02`).

### Intentional additions
The source file is a style-guide + pitch deck, not a component library — it has no formal "Button"/"Card" components, only ad-hoc slide layouts. To make the recurring visual patterns reusable, four small primitives were authored from those patterns (not invented from nothing — each mirrors an exact layout seen repeatedly across slides):
- **IconTile** — the neumorphic white/colored rounded-square icon tile seen throughout the icon page and slide accents.
- **Badge** — the gradient/ghost pill label ("Материал №5") seen on the icon page.
- **InfoCard** — the white/gradient rounded-40 slide card container used on every pitch-deck slide.
- **StatBar** — the vertical bar-chart column with value label from the comparison-chart slides.
- **ListItemCheck** — the tinted checklist row with icon badge from the "Что нужно сделать вам?" slide.

## Content fundamentals
- **Language**: Russian throughout; no English copy in the source.
- **Address**: mixed — "вам" (formal "you") in headlines aimed at clinic owners ("Что нужно сделать вам?"), first-person-plural "мы"/"наша" when describing the company ("Всё, что будет дальше — только наша забота!").
- **Tone**: confident, benefit-led B2B sales copy — short promises with concrete numbers and timeframes ("Создадим стабильный поток пациентов… в течение 3-х месяцев", "Станьте партнёром за 3 дня"). Every claim is backed by a stat (30 → 50-70 → 100-500 patients/month; "3000+ клиниками", "13 000 зарегистрировались").
- **Structure**: headline (bold promise) + one supporting sentence per slide; bullet/checklist slides use two short lines max per item.
- **Emoji**: none. No unicode-icon substitutes either — iconography is always a drawn glyph or 3D illustration.
- **Vibe**: warm, optimistic healthcare-tech — a "helper" positioning ("мы помогаем", "наша забота") over corporate/clinical language.

## Visual foundations
- **Color**: light blue-gray backdrop (`rgb(231,238,249)`) behind white rounded cards. One dominant brand accent — cyan/teal (`rgb(0,185,209)`, lighter `rgb(102,214,228)`) — plus a warm amber/orange (`rgb(255,180,1)`) and a success green (`rgb(35,211,118)`) used sparingly for checklist icons and chart highlights. Heading text is a deep navy-purple (`rgb(55,54,96)`), body text a muted purple-gray (`rgb(94,94,128)`) — never pure black. A violet (`rgb(128,55,252)`) appears occasionally in the wider palette but not on sampled slides.
- **Type**: Montserrat only (weights Regular/Medium/SemiBold/Bold — see Typography caveat below). Display/headline sizes are large (56-80px) and tight (line-height 1.05, +1% tracking); body copy sits at 24-32px with loose 1.4-1.7 line-height and slightly negative tracking (-0.01 to -0.02em) for readability at scale.
- **Spacing**: generous — slide margins are 90px, card padding 40-60px, list gaps 20-30px. Two cards side-by-side per 1920×1080 slide (855-1150px wide, 900px tall, 40px gutter).
- **Backgrounds**: flat color, no photography as full-bleed backdrops. Full-color 3D illustrations (phones, calendars, coffee cups, gift boxes, people, globes) sit inside dedicated illustration cards, never behind text. One recurring soft diagonal gradient (`rgb(198,239,246)→rgb(9,187,210)`) is used for an accent card on ~half the slide types.
- **Animation / hover / press**: none observed — this is a static presentation-deck source, not an interactive product; no motion, hover, or press states are defined.
- **Shadows**: two systems — (1) a soft ambient card shadow `0 0 14px rgba(55,54,96,0.06)` on every white slide card, and (2) a neumorphic dual inset shadow (light `rgba(255,255,255,0.5)` top-left + dark `rgba(0,0,0,0.2)` bottom-right) on icon tiles and small buttons, giving them a soft-pressed, tactile look.
- **Borders**: none — surfaces are separated by shadow and color, not stroke.
- **Corner radii**: large and consistent — 40px on slide cards, 20-22px on icon tiles/chips, pill (999px) on badges.
- **Transparency/blur**: `backdrop-filter: blur()` is used only inside the 3D-illustration compositions (glass-like overlay panels behind phone mockups), never in UI chrome.
- **Imagery color vibe**: warm-neutral, glossy 3D-render style (not photography) — soft studio lighting, no grain, no black & white.

## Iconography
- Icons are custom **outlined/solid line-art glyphs** (17 extracted: phone, mail, marker pin, message bubbles, bank note, bar chart, briefcase, coins, face-smile, check-circle, arrow), always mono-color (`currentColor`) and housed in a neumorphic white or colored rounded-square tile — never used bare.
- No icon font, no emoji, no unicode glyphs as icons.
- A handful of full-color 3D illustrations (see `assets/illustrations/`) act as larger decorative/explanatory visuals (telemedicine, scheduling, gifts, global reach) — distinct from the flat line icons.
- No logo mark exists separately from the **Logo** component — brand mark + wordmark are both drawn as vector paths baked into that component (5 colorways × icon/full-lockup).

## Caveats & open items
- **Typography**: the source uses Montserrat **SemiBold** most heavily (278 uses — headings, labels), but only Regular/Medium/Bold OTF files were uploaded. `font-weight: 600` currently falls back to the Medium file. **Please attach the actual Montserrat SemiBold (and, if available, ExtraBold) OTF/TTF so headings render at their true weight.**
- The file also references a "Suisse Intl SemiBold" for two large numeric labels inside 3D illustration compositions (used only twice, decoratively) — not set up as a system font since it's not used in any UI text.
- No formal Figma Variables existed for typography or spacing — the `tokens/typography.css` and `tokens/spacing.css` scales were derived by reading the actual values used across slides (not rounded to a grid).
- No app or website product screens were present in the source, so no product "UI kit" was built — only the pitch-deck brand and its slide template.
- `components/brand/{Background,CardStyle,MainForm,Rectangle240654316}` are decorative rounded-rectangle "swatch" shapes from the Figma color page, kept for completeness but not meant as general-purpose UI primitives.

**Ask**: tell me if you'd like variations on the slide template (more slide types, a quote/testimonial layout, a closing/CTA slide), a review of the color palette against your latest brand guidelines, or the missing SemiBold font file so all headings render correctly.
