// Hand-authored additions matching the product Icon family's outline style (24px grid, ~1.7 stroke).
// Not sourced from the Figma file — see readme.md "Intentional additions".
export default {
  "Bell": { viewBox: "0 0 24 24", body: "<path d=\"M18 16v-5a6 6 0 1 0-12 0v5l-1.5 2.5h15L18 16Z\"/><path d=\"M9.5 19a2.5 2.5 0 0 0 5 0\"/>" },
  "Settings": { viewBox: "0 0 24 24", body: "<line x1=\"4\" y1=\"7\" x2=\"20\" y2=\"7\"/><circle cx=\"15\" cy=\"7\" r=\"2\" fill=\"var(--icon-bg,#fff)\"/><line x1=\"4\" y1=\"12\" x2=\"20\" y2=\"12\"/><circle cx=\"9\" cy=\"12\" r=\"2\" fill=\"var(--icon-bg,#fff)\"/><line x1=\"4\" y1=\"17\" x2=\"20\" y2=\"17\"/><circle cx=\"17\" cy=\"17\" r=\"2\" fill=\"var(--icon-bg,#fff)\"/>" },
  "VideoCamera": { viewBox: "0 0 24 24", body: "<rect x=\"3\" y=\"7\" width=\"11\" height=\"10\" rx=\"2\"/><path d=\"M14 10.2 20 7v10l-6-3.2\"/>" },
  "Phone": { viewBox: "0 0 24 24", body: "<path d=\"M7.3 10.9c1.3 2.6 3.5 4.7 6 6l2-2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.5.6.6 0 1 .4 1 1V19c0 .6-.4 1-1 1-8.8 0-16-7.2-16-16 0-.6.4-1 1-1h2.9c.6 0 1 .4 1 1 0 1.2.2 2.4.6 3.5.1.4 0 .7-.2 1l-2 1.9Z\"/>" },
  "Lock": { viewBox: "0 0 24 24", body: "<rect x=\"5\" y=\"11\" width=\"14\" height=\"9\" rx=\"2\"/><path d=\"M8 11V7a4 4 0 0 1 8 0v4\"/>" },
  "Pill": { viewBox: "0 0 24 24", body: "<g transform=\"rotate(45 12 12)\"><rect x=\"6\" y=\"3.5\" width=\"12\" height=\"17\" rx=\"6\"/><line x1=\"6\" y1=\"12\" x2=\"18\" y2=\"12\"/></g>" },
  "Wallet": { viewBox: "0 0 24 24", body: "<rect x=\"3\" y=\"6\" width=\"18\" height=\"13\" rx=\"2\"/><path d=\"M3 10h18\"/><rect x=\"14\" y=\"12.5\" width=\"4\" height=\"3\" rx=\"1\"/>" },
  "Plus": { viewBox: "0 0 24 24", body: "<circle cx=\"12\" cy=\"12\" r=\"9\"/><line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"16\"/><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"/>" },
  "Edit": { viewBox: "0 0 24 24", body: "<path d=\"M15.7 4.3a2 2 0 0 1 2.8 0l1.2 1.2a2 2 0 0 1 0 2.8L8.5 19.5 4 20.5l1-4.5L15.7 4.3Z\"/>" },
  "Download": { viewBox: "0 0 24 24", body: "<path d=\"M12 4v11\"/><polyline points=\"7 11 12 16 17 11\"/><line x1=\"5\" y1=\"20\" x2=\"19\" y2=\"20\"/>" },
  "Upload": { viewBox: "0 0 24 24", body: "<path d=\"M12 15V4\"/><polyline points=\"7 9 12 4 17 9\"/><line x1=\"5\" y1=\"20\" x2=\"19\" y2=\"20\"/>" },
  "Info": { viewBox: "0 0 24 24", body: "<circle cx=\"12\" cy=\"12\" r=\"9\"/><line x1=\"12\" y1=\"11\" x2=\"12\" y2=\"16\"/><line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"8.01\"/>" },
  "Warning": { viewBox: "0 0 24 24", body: "<path d=\"M12 4 21 19H3Z\"/><line x1=\"12\" y1=\"10\" x2=\"12\" y2=\"14\"/><line x1=\"12\" y1=\"17\" x2=\"12\" y2=\"17.01\"/>" },
  "Trash": { viewBox: "0 0 24 24", body: "<path d=\"M5 7h14\"/><path d=\"M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2\"/><path d=\"M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13\"/><line x1=\"10\" y1=\"11\" x2=\"10\" y2=\"17\"/><line x1=\"14\" y1=\"11\" x2=\"14\" y2=\"17\"/>" },
  "Mic": { viewBox: "0 0 24 24", body: "<rect x=\"9\" y=\"3\" width=\"6\" height=\"11\" rx=\"3\"/><path d=\"M5 11a7 7 0 0 0 14 0\"/><line x1=\"12\" y1=\"18\" x2=\"12\" y2=\"22\"/><line x1=\"8\" y1=\"22\" x2=\"16\" y2=\"22\"/>" },
  "Eye": { viewBox: "0 0 24 24", body: "<path d=\"M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7Z\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>" },
  "EyeOff": { viewBox: "0 0 24 24", body: "<path d=\"M4.6 6.6C3 8 2 9.6 2 9.6s4 7 10 7c1.4 0 2.7-.4 3.8-1\"/><path d=\"M9.5 8.6a3 3 0 0 1 4.2 4.2\"/><path d=\"M8.9 15.4C7.9 15.9 7 16.6 6.2 17\"/><path d=\"M14.8 5.4C16.9 6 18.9 7.7 22 9.6c0 0-.4.7-1.2 1.7\"/><line x1=\"3\" y1=\"3\" x2=\"21\" y2=\"21\"/>" },
  "ChevronUp": { viewBox: "0 0 24 24", body: "<polyline points=\"6 15 12 9 18 15\"/>" },
  "ChevronDown": { viewBox: "0 0 24 24", body: "<polyline points=\"6 9 12 15 18 9\"/>" },
  "ArrowLeft": { viewBox: "0 0 24 24", body: "<line x1=\"20\" y1=\"12\" x2=\"4\" y2=\"12\"/><polyline points=\"10 6 4 12 10 18\"/>" },
  "ArrowRight": { viewBox: "0 0 24 24", body: "<line x1=\"4\" y1=\"12\" x2=\"20\" y2=\"12\"/><polyline points=\"14 6 20 12 14 18\"/>" },
  "LogOut": { viewBox: "0 0 24 24", body: "<path d=\"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4\"/><polyline points=\"16 17 21 12 16 7\"/><line x1=\"21\" y1=\"12\" x2=\"9\" y2=\"12\"/>" },
  "MoreVertical": { viewBox: "0 0 24 24", body: "<circle cx=\"12\" cy=\"6\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"12\" cy=\"12\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"12\" cy=\"18\" r=\"1.4\" fill=\"currentColor\" stroke=\"none\"/>" },
  "Clock": { viewBox: "0 0 24 24", body: "<circle cx=\"12\" cy=\"12\" r=\"9\"/><polyline points=\"12 7 12 12 15.5 14\"/>" }
};
