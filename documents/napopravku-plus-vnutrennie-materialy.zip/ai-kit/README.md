# НаПоправку Плюс — Design System

**НаПоправку Плюс** ("get well soon / recovery, Plus") is a Russian-language telemedicine subscription brand: a mobile app that gives employees/families in-app chat consultations with doctors, appointment booking, clinic/doctor directories, and health-service categories (pulmonology, dentistry, pediatrics, tests, etc). The source material is a corporate brand style-guide deck ("Руководство по использованию фирменного стиля") plus a small set of real product screens (iPhone SE mockups of the home/booking flow) embedded in the same file.

**Source:** a Figma file named "Style guide telemed (Copy)" (mounted read-only for this import; no public share link was provided). Pages used: `Guide` (the numbered brand-guide sections 1–5: Logo, Color, Font, Ad graphics, Links), `Components`, `icon`, `badges`, `photo`, `font`, `cover`. The file's large `work` page (322 frames) is mostly unrelated moodboard/reference material accumulated in the same file — see "Intentional omissions" below.

## Content fundamentals
- All source copy is Russian, second person is avoided — copy speaks about the subscriber in third person/impersonal register ("сотрудник сможет получить консультацию…" — "the employee will be able to get a consultation…").
- Headlines are short, benefit-first promises: "Подписка на здоровье для всей семьи" ("A subscription to health for the whole family"), "Запись на удобное время" ("Booking at a convenient time").
- Tone is calm, reassuring, plain-spoken — no jokes, no exclamation marks, no emoji anywhere in the source.
- Section labels in the guide use plain numbered headers ("2.1 Основные цвета") in a muted gray — a quiet, technical, unembellished documentation voice.

## Typographic rules for Russian copy (non-breaking spaces)
Never leave a hanging preposition or conjunction at the end of a line. Every deliverable built from this system (slides, brandbook pages, screens, marketing copy) must be typeset with `&nbsp;` / `\u00A0` in these positions:
- **After short prepositions and conjunctions** (1–3 letters): `в к с у о и а я не ни но же ли бы во со об на за по до от из то для при над под без про как что или если чем уже где это`. Example: `запись на приём` → `запись на\u00A0приём`.
- **Between a number and its unit or noun**: `1,2 млн`, `480 тыс.`, `35 ₽`, `+41 %`, `6 мес`, `15 городов`, `3 врача` → all joined with a non-breaking space.
- **Before an em/en dash**: the dash stays with the preceding word — `сервис\u00A0— это`, never a dash starting a new line.
- **After `№`**: `№\u00A05`.
- Initials and abbreviations stay together: `И.\u00A0И.\u00A0Иванов`, `т.\u00A0е.`
- Pair with `text-wrap: pretty` on paragraph-level text so the last line never holds a single short word.

Applied across `templates/presentation/Presentation.dc.html` (109 text nodes). When authoring new copy, apply the same rule before shipping.

## Visual foundations
- **Color:** Violet `#8037FC` is the dominant primary (used for backgrounds, the wordmark capsule, and primary buttons). Orange `#FFB401` and Teal `#00B9D2` are the two accent brand colors, always paired with violet in the mark itself (see Logo). Navy `#373660` is the dark neutral for headings/dark surfaces. Green/Red are semantic-only (success/error), not used decoratively.
- **Type:** Montserrat only, across every weight (Regular/Medium/SemiBold/Bold). Headline sizes are large and confident (up to 120px on cover slides); body copy sits at a generous 20–24px with 1.6 line-height.
- **Logo:** corrected against the user's authoritative source file (`uploads/logo.svg`) — the mark is an orange (`#FFB401`) rounded square containing a white interlocking-loop glyph (evoking a ribbon/infinity form), not the violet five-circle mark earlier drafts showed. The wordmark is custom-drawn vector letterforms (not a font) designed to sit in white on the brand's colored/dark surfaces (violet, navy) — it has no separate dark-on-light variant in the source, so don't place it on white/light backgrounds.
- **Backgrounds:** flat brand-color fields (violet, light-violet tint `#E6D7FE`) behind ad graphics; no gradients, patterns, or textures in the system — one exception is a soft radial "light-gradient" logo variant for use on dark/photo backgrounds.
- **Photography:** warm, candid lifestyle/portrait photography (doctors, families) — never stock-cold or heavily filtered; always cropped into rounded full-bleed shapes rather than plain rectangles.
- **Cards/surfaces:** large radius (20–40px), white fill, either a thin 2px light-violet inset ring or a soft navy-tinted drop shadow (`rgba(31,70,76,0.16)`) — never a hard black shadow, never a colored left border accent.
- **Corner radii:** big and consistent — 20px small components, 38–40px large cards/blocks, full-pill for tags/coins/buttons.
- **Borders:** thin 1px `#D7D7DF` hairlines used only for guide-page section headers and calendar/list dividers — not used decoratively on cards.
- No motion, hover, or press-state specs were present in the source; treat interactive states as an open item (see Caveats).

## Iconography
- The product's real icon set is a small outlined-glyph family: 24px (rare 16px) stroke icons for navigation (Home, Search, Chevrons, Filter, Sort), medical categories (Doctor, Clinic, Kid, Tests, health specialties), and messaging (Chat, Send, Reply, Paperclip). A handful of filled/colored icons cover coins, subscription state, and a filled star rating glyph. These are vector (no icon font) and now live in `assets/icons/` as one data file — render with `<Icon name="OutlinedHeart24" />`.
- **Intentional omission:** the same Figma file also contains a large (~350-member) generic marketing/analytics icon library (brand logos for Facebook, Chrome, GitHub, Google Analytics, Hubspot, Semrush products, app-store badges, OS/device glyphs, etc.) bundled in on the `icon`/`badges` pages. These are third-party reference icons, not part of the НаПоправку Плюс product's own visual language, so they were **not** built into this system. App-store/social badges are standard third-party marks and were likewise left out — reattach the source and ask if you need them recreated.
- No emoji or Unicode-symbol icons appear anywhere in the source.

## Intentional additions
- `CustomIcon` (`assets/icons-custom/`) — 24 hand-designed outline glyphs matching the product `Icon` family's visual weight (24px grid, ~1.7px rounded stroke), filling common gaps the source file doesn't cover: Bell, Settings, VideoCamera, Phone, Lock, Pill, Wallet, Plus, Edit, Download, Upload, Info, Warning, Trash, Mic, Eye, EyeOff, ChevronUp, ChevronDown, ArrowLeft, ArrowRight, LogOut, MoreVertical, Clock.
- `ExtendedIcon` (`assets/icons-extended/`) — not a kit component name; it's a wrapper for the 101 bundled generic, non-trademarked icon glyphs (Airplane, Calendar, Chart*, Document*, Folder*, etc.), named descriptively rather than reusing any single glyph's name, mirroring the same wrapper pattern already used for the brand's own `Icon`.

## Colors, type, spacing tokens
See `tokens/colors.css`, `tokens/typography.css`, `tokens/spacing.css`, `tokens/effects.css` (all imported by root `styles.css`). Montserrat is loaded from Google Fonts (exact match — no substitution needed).

## Components built (38)
- **Brand** (`assets/logo/`): `LogotypeFull` / `LogotypeFullMonoDark` / `LogotypeFullMonoLight`, `Logo` (the standalone mark) — rebuilt directly from the user-supplied `logotype-main.svg`, the authoritative logo asset (also copied verbatim into `assets/logo/logotype-main.svg`).
- **Icons** (`assets/icons/`): `Icon` — 44-name outlined/filled/colored icon set (see Iconography).
- **Buttons** (`components/buttons/`): `ButtonLargePrimaryLabelActive`, `ButtonLargeTetriaryLabelIcon`, `ButtonTagExtraLargeValueINActive`, `ButtonTagLargeValueActive`, `ButtonTagLargeValueIcon`, `ButtonTagSmallValueInActive`, plus their nested `IconHeart`/`IconArrowChevronRight`.
- **Controls** (`components/controls/`): `ControlsSegmentedControlControlLarge`, `TabsCalendarDayEmpty`, `TabsCalendarDayInActive`, `Calendar`, `ControlBottomSheetDropdown`.
- **Data display** (`components/data-display/`): `AvatarUser` (15 sex/hair/length variants), `AvatarDocClinic` (5 type variants), `Card`, `CardReviews`, `Cards`, `TagDefault`, `TagReview2`, plus nested icons (`Icon16OutlinedService`, `Icon16StarSolid`, `Icon24OutlinedComment`, `Icon24OutlinedLike`, `Icon24OutlinedEdit`, `Icon24FilledPhone`, `Icon24OutlinedClock`, `Icon24OutlinedCheck`, `Icon24OutlinedHelp`, `Icon24OutlinedClose`, `Icon24OutlinedShield`).
- **Feedback** (`components/feedback/`): `TagCommentsApprove`, `IconShield`.

## Component coverage — 139 individual glyphs/components built (39 bundle exports) of 408 Figma "component families"; ~270 intentionally skipped
Note on counting: the design-system compiler counts *bundle exports* (39: `Icon`, `ExtendedIcon`, `Logo`, and 36 named UI components), not individual icon glyphs inside an icon-data file — so it will always report "39 of 408" even though `Icon` + `ExtendedIcon` alone cover 139 distinct glyphs (44 product icons + 101 generic icons). The gap to 408 is entirely the intentionally-skipped trademarked library below, not missed brand work.
The source Figma file's raw inventory reports 408 component families:
- **38 are НаПоправку Плюс's own real, reusable UI primitives** — logo, product icon set, buttons, controls, avatars, cards, tags (built above, `components/` + `assets/logo` + `assets/icons`).
- **101 more are a bundled, non-trademarked generic icon set** (`Airplane`, `Archive`, `Calendar`, `Chart*`, `Chat*`, `Chevron*`, `Document*`, `Folder*`, `Format Align*`, `Gender*`, etc.) — plain pictographic glyphs with no brand or trademark association. These were built too, as `ExtendedIcon` in `assets/icons-extended/`, for completeness even though they aren't part of the brand's own drawn iconography (see Iconography above for which set is the "real" product icon system).
- **The remaining ~270 are deliberately NOT built**, because they are not НаПоправку Плюс components at all — they are a separate, unrelated **third-party trademarked** icon/logo/badge/payment-card library bundled into the same .fig file (evidenced by literal product names like `Prowly`, `Sellzone`, `SemrushRank`, and by a `/icon/components` folder of ~560 `SizeL#`/`SizeM#` instance duplicates of the same set). It consists of:
  - **Brand/OS/browser logos** — `Chrome`, `Firefox`, `Figma`, `GitHub`, `GitLab`, `Facebook`, `FacebookMessenger`, `Google*` (Analytics, Cloud, Docs, Mail, Search Console…), `Hubspot`, `Adobe*`, `Android`, `Apple`, `Amp`, `Foursquare`.
  - **Payment-network logos** — Visa, MasterCard, PayPal, Amex, Discover, JCB, UnionPay, WeChatPay (`PayIcon*`).
  - **App/browser store badges** — Apple/Google/Amazon/Huawei/Samsung/Microsoft/Shopify/Spotify store badges.
  
  These are other companies' trademarked marks, not this brand's UI — reproducing them as "НаПоправку Плюс design-system components" would be both a trademark issue and a misrepresentation of the brand's actual UI kit, so they were intentionally excluded. Ask if you specifically need one recreated for a real integration (e.g. an actual App Store badge for a landing page).

## Index
- `styles.css`, `tokens/` — global tokens (colors, type, spacing, effects)
- `assets/logo/` — logo & wordmark components + `logo.card.html`
- `assets/icons/` — icon data + `Icon` component + `icons.card.html`
- `assets/photos/` — real brand photography samples
- `components/buttons/`, `components/controls/`, `components/data-display/`, `components/feedback/` — UI primitives, each with a `.card.html` demo
- `guidelines/` — foundation specimen cards (color, type, spacing, radius/shadow, photography)
- `ui_kits/mobile-app/` — recreated app screens (Home, Doctor profile, Booking)
- `SKILL.md` — portable skill file for use in Claude Code

## Caveats
- No Figma Variables (design tokens) or named text styles existed in the source file — all tokens above were derived by hand from the literal values used across the Guide pages, not from a Variables collection.
- Interactive states (hover/press/focus) are not documented in the source; button/control states shown here are inferred from the single "Active" variant present in the file.
- Only 3 sample photos were copied in (of a much larger photo library in the source) to keep the project light — ask if you'd like more pulled in.
