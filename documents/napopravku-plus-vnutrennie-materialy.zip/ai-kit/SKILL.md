# napopravku-plus-design

---
name: napopravku-plus-design
description: Use this skill to generate well-branded interfaces and assets for НаПоправку Плюс (a Russian telemedicine subscription brand), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files. Note the "Typographic rules for Russian copy" section — non-breaking spaces after short prepositions, between numbers and units, and before em dashes are mandatory in every deliverable.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
